
import java.util.ArrayList;
import java.util.LinkedList;

public class TodaysRatingsAL implements ISet{

	//fields
	private ArrayList<TodaysRatings> listOfRatings = new ArrayList<TodaysRatings>();
	
	//constructor
	public TodaysRatingsAL (ArrayList<TodaysRatings> listOfRatings) {
		this.listOfRatings = listOfRatings;
	}
	
	//equals method override, for test cases
	/**
	 * Compares two todays ratings array list to see if they are equal
	 * @param obj The object you're comparing.
	 * @return True if the two array list are equal. False otherwise.
	 */
	public boolean equals(Object obj) {
		
		TodaysRatingsAL aLL = (TodaysRatingsAL) obj;
		
		return this.listOfRatings.equals(aLL.listOfRatings);
	}
	
	/**
	 * Add a todaysRating to the list
	 * @param aRatings a rating to add
	 * @return updated array list
	 */
	public TodaysRatingsAL add(TodaysRatings aRatings){
		
		this.listOfRatings.add(aRatings);
		
		return this;
	}
	
	/**
	 * Find and produce a list of ratings within given month
	 * @param month, year input month and year
	 * @return a list of ratings within given month
	 */
	public LinkedList<TodaysRatings> findRatings(int month, int year){
	
		LinkedList<TodaysRatings> aList = new LinkedList<TodaysRatings>();
	
	for(TodaysRatings aRatings : this.listOfRatings) {
		if(aRatings.withinMonth(month, year)) {
			aList.add(aRatings);
		}
	}
	
	return aList;
	}
	
}
