import java.util.LinkedList;

public interface ISet {

	//common methods
	ISet add(TodaysRatings aRatings);
	LinkedList<TodaysRatings> findRatings(int month, int year);
	boolean equals(Object obj);
}
