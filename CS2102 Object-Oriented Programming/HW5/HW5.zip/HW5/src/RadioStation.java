
import java.util.GregorianCalendar;
import java.util.LinkedList;

public class RadioStation {

	//fields
	private ISet setOfTodaysRatings;
	private GregorianCalendar date;
	
	//constructor
	public RadioStation(ISet setOfTodaysRatings, GregorianCalendar date) {
		this.setOfTodaysRatings = setOfTodaysRatings;
		this.date = date;
	}
	
	//equals method override, for test cases
	/**
	 * Compares two radio stations to see if the set of ratings and date are equal
	 * @param obj The object you're comparing.
	 * @return True if the two radio station are equal. False otherwise.
	 */
	public boolean equals(Object aObj) {
		
		RadioStation aStation = (RadioStation) aObj;
		
		return this.setOfTodaysRatings.equals(aStation.setOfTodaysRatings) &&
			   this.date.equals(aStation.date);
	}
	
	/**
	 * Find and produce a list of ratings within given month
	 * @param month, year input month and year
	 * @return a list of ratings within given month
	 */
	public LinkedList<TodaysRatings> findRatings(int month, int year){
		
		return this.setOfTodaysRatings.findRatings(month, year);
	}
	
	/**
	 * Find and produce a list of ratings within the month of the current date
	 * @return a list of ratings within this month
	 */
	public LinkedList<TodaysRatings> findRatingsThisMonth(){
		
		int month = this.date.get(GregorianCalendar.MONTH);
		int year = this.date.get(GregorianCalendar.YEAR);
		
		return this.findRatings(month, year);
	}
	
	/**
	 * Produce the number of total song downloads within the given month
	 * @param month, year input month and year
	 * @return total song downloads
	 */
	public int totalSongDownloads(int month, int year) {
		
		LinkedList<TodaysRatings> aList = this.findRatings(month, year);
		
		int totalDownloads = 0;
		
		for(TodaysRatings aRatings : aList) {
			
			totalDownloads += aRatings.totalDownloadsToday();
		}
		
		return totalDownloads;
	}
	
	/**
	 * Gather a list of survey and update the radio station
	 * @param listOfSurveys a list of surveys
	 * @return the updated radio station
	 */
	public RadioStation addTodaysSurveys(LinkedList<Survey> listOfSurveys) {
		
	    int year = this.date.get(GregorianCalendar.YEAR);
	    int month = this.date.get(GregorianCalendar.MONTH);
	    int day = this.date.get(GregorianCalendar.DAY_OF_MONTH);
	    
		GregorianCalendar oldDate = new GregorianCalendar(year, month, day); 		
		TodaysRatings todaysRatings = new TodaysRatings(oldDate);
		todaysRatings.gatherSurveys(listOfSurveys);		
		this.setOfTodaysRatings.add(todaysRatings);
		
		GregorianCalendar newDate = new GregorianCalendar(year, month, day); 		
		newDate.add(GregorianCalendar.DAY_OF_YEAR, 1);
		this.date = newDate;

		return this;
	}
	
	/**
	 * Produce the best rank in this month
	 * @return the best rank
	 */
	public int bestRankThisMonth() {
		
		int smallestRank ;
		
		LinkedList<TodaysRatings> aList = new LinkedList<TodaysRatings>();
		aList = this.findRatingsThisMonth();
		
		if(!aList.isEmpty()) {
			
			smallestRank = aList.get(0).bestRankToday();
			
			for(TodaysRatings aRatings : aList) {
				
				if(aRatings.bestRankToday() < smallestRank) {
					smallestRank = aRatings.bestRankToday();
				}
			}
		}
		else {
			
			//if empty list, produce -1
			smallestRank = -1;
		}
		
		return smallestRank;
	}
}

//Answers:
/*
	1. We can use an array list. This is because dates are in numerical order. If we use array list, a todaysRatings object
	   can be easily found by the date. Let's say list[0]'s date is 2022/12/01, then if we want to find the todays ratings object
	   whose date is 2022/12/05, then it should be at list[4].
	2. If I use an array list. I just need to create methods that functions as it were a linked list.
	3. Yes, we just need to make the new class implement the methods from the interface. And write the method body in the new class
	   to make it do the same thing the other class do. Then in the example or main class, all we need to do is to construct a 
	   radio station object, which uses the new class.
*/
