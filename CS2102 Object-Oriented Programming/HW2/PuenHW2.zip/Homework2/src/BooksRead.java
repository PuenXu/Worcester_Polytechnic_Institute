
public class BooksRead {
	
	//fields declaration
	double booksRead;
	String genre;
	boolean skimmedOrNot; 
	
	//Constructor
	
	public BooksRead(double booksRead, String genre, boolean skimmedOrNot) {
		
		this.booksRead = booksRead;
		this.genre = genre;
		this.skimmedOrNot = skimmedOrNot;
	}
}
