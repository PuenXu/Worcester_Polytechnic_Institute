
public interface IChallenge {

	//Methods required
	
	double averagePerDay();
	double differenceFromGoal();
}
