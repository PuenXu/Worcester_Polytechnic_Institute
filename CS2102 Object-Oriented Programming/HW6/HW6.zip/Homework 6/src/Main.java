
public class Main {
    public static void main(String[] args) {
        
        //Run it and have fun with the polling interface!
    	PollingDevice d1 = new PollingDevice();
    	d1.screen();
    	
    }
}
