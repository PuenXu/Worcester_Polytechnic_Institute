
public class BooksRead {
	
	double booksRead;
	
	public BooksRead(double booksRead) {
		
		this.booksRead = booksRead;
	}
}
