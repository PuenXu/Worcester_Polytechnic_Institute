
public interface IChallenge {

	double averagePerDay();
	double differenceFromGoal();
}
